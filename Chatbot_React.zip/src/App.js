import React, { useState } from "react";
import { BsEmojiSmile, BsMenuButton } from "react-icons/bs";
import "./App.css";
import data from "./data.json";

const Chatbot = () => {
  const [messages, setMessages] = useState([data.welcome]);
  const [show,setShow]=useState(true);
  //const [isActive, setIsActive] = useState(false);
  const [visible, setVisible] = useState(true);

  const removeElement = () => {
    setVisible((prev) => !prev);
  };
  
  return (
    <center>
      <div className="chatbot">
        {messages.map((sus) => (
          <div>
            <p>{sus.title}</p>

            {sus.children.map((button) => (
              <button  
                key={button.title} 
                onClick={() => {removeElement,setMessages([...messages,sus[button.value]])}}
              >
                {show && button.title}

              </button>
            ))}
             
            
              {sus.children.map((button) => (
               show && <h4> button.title </h4>                 
              ))}
            
          </div>

        )
        )}
      </div>
    </center>
  );
};

export default Chatbot;